package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Buyer;
import com.example.demo.entity.Product;
import com.example.demo.service.BuyerService;

@RestController
public class BuyerController {
	@Autowired
	public BuyerService serv;
	
	
	@GetMapping("/getAll")
	public List<Product> getAllProducts()
	{
		return serv.getAllProducts();
	}
	@GetMapping("/gellAllUsers")
	public List<Buyer> getUsers()
	{
		return serv.getUsers();
	}
	@PostMapping("/addUser")
	public String addProduct(@RequestBody Buyer buyer)
	{
		return serv.addProduct(buyer);
	}
}
